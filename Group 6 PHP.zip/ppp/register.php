<?php
session_start();
require 'db.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';

    if (!$fullname) $errors[] = 'Full name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        // check existing email
        $stmt = $mysqli->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = 'An account with that email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $ins = $mysqli->prepare('INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)');
            $ins->bind_param('sss', $fullname, $email, $hash);
            if ($ins->execute()) {
                $_SESSION['user_id'] = $ins->insert_id;
                $_SESSION['user_name'] = $fullname;
                header('Location: dashboard.php');
                exit;
            } else {
                $errors[] = 'Registration failed. Try again later.';
            }
        }
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Register - Study Planner</title>
<link rel="stylesheet" href="styles.css">
</head>
<body class="centered">
  <div class="card">
    <h1>Create account</h1>
    <?php if (!empty($errors)): ?>
      <div class="errors">
        <?php foreach($errors as $e) echo '<p>'.htmlspecialchars($e).'</p>'; ?>
      </div>
    <?php endif; ?>

    <form method="post" action="register.php" novalidate>
      <label>Full name
        <input type="text" name="fullname" value="<?php echo htmlspecialchars($_POST['fullname'] ?? '') ?>" required>
      </label>
      <label>Email
        <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </label>
      <label>Password
        <input type="password" name="password" required>
      </label>
      <label>Confirm password
        <input type="password" name="confirm" required>
      </label>
      <button class="btn" type="submit">Register</button>
    </form>

    <p class="muted">Already have an account? <a href="login.php">Sign in</a></p>
  </div>
</body>
</html>
