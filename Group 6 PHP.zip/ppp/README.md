Study Planner Website (PHP + MySQL)
----------------------------------

Files:
- db.php            : Database connection (configure DB credentials)
- register.php      : Registration form & processing
- login.php         : Login form & processing
- dashboard.php     : Logged-in user's study planner dashboard (add/view tasks)
- logout.php        : Log out
- index.php         : Landing page (redirects to login or dashboard)
- styles.css        : Beautiful CSS
- sql/create_db.sql : SQL to create database and tables

Instructions:
1. Create a MySQL database and user. Update `db.php` with your DB credentials.
2. Import `sql/create_db.sql` into your MySQL server (e.g., via `mysql -u root -p < create_db.sql`).
3. Place the files in a PHP-enabled web server (e.g., XAMPP, LAMP) document root.
4. Open index.php in your browser.

Security notes:
- Passwords are hashed using password_hash().
- Prepared statements are used to prevent SQL injection.
- This is a simple educational example; for production, enable HTTPS, add CSRF protections, input validation, and rate-limiting.
