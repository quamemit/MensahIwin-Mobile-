<?php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$uid = $_SESSION['user_id'];
$errors = [];

// handle add task
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = trim($_POST['title'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $due = $_POST['due_date'] ?? null;
    if (!$title) $errors[] = 'Task title is required.';
    if (empty($errors)) {
        $ins = $mysqli->prepare('INSERT INTO tasks (user_id, title, description, due_date) VALUES (?, ?, ?, ?)');
        if (!$ins) die("Prepare failed: " . $mysqli->error);
        $ins->bind_param('isss', $uid, $title, $desc, $due);
        $ins->execute();
    }
}

// toggle complete
if (isset($_GET['toggle'])) {
    $tid = (int)$_GET['toggle'];
    $up = $mysqli->prepare('UPDATE tasks SET completed = 1 - completed WHERE id = ? AND user_id = ?');
    if ($up) {
        $up->bind_param('ii', $tid, $uid);
        $up->execute();
    }
    header('Location: dashboard.php');
    exit;
}

// delete
if (isset($_GET['delete'])) {
    $tid = (int)$_GET['delete'];
    $del = $mysqli->prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?');
    if ($del) {
        $del->bind_param('ii', $tid, $uid);
        $del->execute();
    }
    header('Location: dashboard.php');
    exit;
}

// fetch tasks
$tasks = [];
$query = "
    SELECT id, title, description, due_date, completed, created_at
    FROM tasks
    WHERE user_id = ?
    ORDER BY (due_date IS NULL) ASC, due_date ASC, created_at DESC
";
$res = $mysqli->prepare($query);
if (!$res) {
    die("Prepare failed: " . $mysqli->error);
}
$res->bind_param('i', $uid);
$res->execute();
$res->bind_result($id, $title, $description, $due_date, $completed, $created_at);
while ($res->fetch()) {
    $tasks[] = [
        'id'=>$id, 'title'=>$title, 'description'=>$description,
        'due_date'=>$due_date, 'completed'=>$completed, 'created_at'=>$created_at
    ];
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - Study Planner</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="topbar">
    <div class="wrap">
      <h2>Study Planner</h2>
      <div class="user">Hello, <?php echo htmlspecialchars($_SESSION['user_name']); ?> — <a href="logout.php">Log out</a></div>
    </div>
  </header>

  <main class="wrap">
    <section class="left">
      <div class="card">
        <h3>Add task</h3>
        <?php if (!empty($errors)): ?>
          <div class="errors"><?php foreach($errors as $e) echo '<p>'.htmlspecialchars($e).'</p>'; ?></div>
        <?php endif; ?>
        <form method="post" action="dashboard.php">
          <input type="hidden" name="action" value="add">
          <label>Title<input type="text" name="title" required></label>
          <label>Description<textarea name="description"></textarea></label>
          <label>Due date<input type="date" name="due_date"></label>
          <button class="btn" type="submit">Add</button>
        </form>
      </div>
    </section>

    <section class="right">
      <div class="card">
        <h3>Your tasks</h3>
        <?php if (empty($tasks)): ?>
          <p class="muted">No tasks yet — add one on the left.</p>
        <?php else: ?>
          <ul class="tasks">
            <?php foreach($tasks as $t): ?>
              <li class="<?php echo $t['completed'] ? 'done' : ''; ?>">
                <div class="t-title"><?php echo htmlspecialchars($t['title']); ?></div>
                <?php if ($t['due_date']): ?><div class="t-due">Due: <?php echo htmlspecialchars($t['due_date']); ?></div><?php endif; ?>
                <?php if ($t['description']): ?><div class="t-desc"><?php echo nl2br(htmlspecialchars($t['description'])); ?></div><?php endif; ?>
                <div class="t-actions">
                  <a href="?toggle=<?php echo $t['id']; ?>"><?php echo $t['completed'] ? 'Mark incomplete' : 'Mark complete'; ?></a>
                  <a class="danger" href="?delete=<?php echo $t['id']; ?>" onclick="return confirm('Delete this task?')">Delete</a>
                </div>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </section>
  </main>

  <footer class="wrap muted">Built with ❤️ — Study Planner</footer>
</body>
</html>
