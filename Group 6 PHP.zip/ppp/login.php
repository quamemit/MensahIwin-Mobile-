<?php
session_start();
require 'db.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (!$password) $errors[] = 'Password is required.';

    if (empty($errors)) {
        $stmt = $mysqli->prepare('SELECT id, fullname, password FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->bind_result($id, $fullname, $hash);
        if ($stmt->fetch()) {
            if (password_verify($password, $hash)) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $id;
                $_SESSION['user_name'] = $fullname;
                header('Location: dashboard.php');
                exit;
            } else {
                $errors[] = 'Incorrect email or password.';
            }
        } else {
            $errors[] = 'Incorrect email or password.';
        }
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login - Study Planner</title>
<link rel="stylesheet" href="styles.css">
</head>
<body class="centered">
  <div class="card">
    <h1>Welcome back</h1>
    <?php if (!empty($errors)): ?>
      <div class="errors">
        <?php foreach($errors as $e) echo '<p>'.htmlspecialchars($e).'</p>'; ?>
      </div>
    <?php endif; ?>

    <form method="post" action="login.php" novalidate>
      <label>Email
        <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </label>
      <label>Password
        <input type="password" name="password" required>
      </label>
      <button class="btn" type="submit">Sign in</button>
    </form>

    <p class="muted">Don't have an account? <a href="register.php">Create one</a></p>
  </div>
</body>
</html>
